import React from 'react';
import { Download, Eye, Share } from 'lucide-react';
import { ResumeData } from '../../types/resume';
import ModernTemplate from './templates/ModernTemplate';

interface ResumePreviewProps {
  resumeData: ResumeData | null;
  template: string;
}

const ResumePreview: React.FC<ResumePreviewProps> = ({ resumeData, template }) => {
  const handleDownload = (format: 'pdf' | 'docx') => {
    // Mock download functionality
    console.log(`Downloading resume as ${format.toUpperCase()}`);
  };

  const renderTemplate = () => {
    if (!resumeData) {
      return (
        <div className="bg-white h-full flex items-center justify-center text-gray-500">
          <div className="text-center">
            <Eye className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Resume preview will appear here</p>
          </div>
        </div>
      );
    }

    switch (template) {
      case 'modern':
        return <ModernTemplate data={resumeData} />;
      case 'classic':
        return <ModernTemplate data={resumeData} />;
      case 'creative':
        return <ModernTemplate data={resumeData} />;
      default:
        return <ModernTemplate data={resumeData} />;
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Preview Header */}
      <div className="bg-white border-b border-gray-200 p-4 flex items-center justify-between">
        <h3 className="font-semibold text-gray-900">Live Preview</h3>
        
        <div className="flex items-center space-x-2">
          <button
            onClick={() => handleDownload('pdf')}
            className="flex items-center px-3 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download size={16} className="mr-1" />
            PDF
          </button>
          
          <button
            onClick={() => handleDownload('docx')}
            className="flex items-center px-3 py-2 bg-gray-600 text-white text-sm rounded-lg hover:bg-gray-700 transition-colors"
          >
            <Download size={16} className="mr-1" />
            Word
          </button>
          
          <button className="flex items-center px-3 py-2 bg-gray-200 text-gray-700 text-sm rounded-lg hover:bg-gray-300 transition-colors">
            <Share size={16} className="mr-1" />
            Share
          </button>
        </div>
      </div>

      {/* Preview Content */}
      <div className="flex-1 p-6 bg-gray-100 overflow-auto">
        <div className="max-w-2xl mx-auto bg-white shadow-lg min-h-full">
          {renderTemplate()}
        </div>
      </div>
    </div>
  );
};

export default ResumePreview;