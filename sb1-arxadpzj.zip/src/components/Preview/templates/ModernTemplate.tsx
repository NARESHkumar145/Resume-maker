import React from 'react';
import { ResumeData } from '../../../types/resume';
import { Mail, Phone, MapPin, Globe, Linkedin } from 'lucide-react';

interface ModernTemplateProps {
  data: ResumeData;
}

const ModernTemplate: React.FC<ModernTemplateProps> = ({ data }) => {
  const { contactInfo, experience, education, skills } = data;

  return (
    <div className="bg-white p-8 min-h-full">
      {/* Header */}
      <div className="border-b-2 border-blue-600 pb-6 mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          {contactInfo.fullName || 'Your Name'}
        </h1>
        
        <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600">
          {contactInfo.email && (
            <div className="flex items-center">
              <Mail size={14} className="mr-1" />
              {contactInfo.email}
            </div>
          )}
          {contactInfo.phone && (
            <div className="flex items-center">
              <Phone size={14} className="mr-1" />
              {contactInfo.phone}
            </div>
          )}
          {contactInfo.location && (
            <div className="flex items-center">
              <MapPin size={14} className="mr-1" />
              {contactInfo.location}
            </div>
          )}
          {contactInfo.linkedIn && (
            <div className="flex items-center">
              <Linkedin size={14} className="mr-1" />
              LinkedIn
            </div>
          )}
          {contactInfo.website && (
            <div className="flex items-center">
              <Globe size={14} className="mr-1" />
              Portfolio
            </div>
          )}
        </div>
      </div>

      {/* Summary */}
      {contactInfo.summary && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 text-blue-600">
            Professional Summary
          </h2>
          <p className="text-gray-700 leading-relaxed">{contactInfo.summary}</p>
        </div>
      )}

      {/* Experience */}
      {experience.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 text-blue-600">
            Work Experience
          </h2>
          <div className="space-y-6">
            {experience.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                    <p className="text-blue-600 font-medium">{exp.company}</p>
                  </div>
                  <div className="text-right text-sm text-gray-600">
                    <p>{exp.location}</p>
                    <p>
                      {exp.startDate} - {exp.current ? 'Present' : exp.endDate}
                    </p>
                  </div>
                </div>
                {exp.description.length > 0 && (
                  <ul className="list-disc list-inside space-y-1 text-gray-700 ml-4">
                    {exp.description.map((desc, idx) => (
                      <li key={idx}>{desc}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education */}
      {education.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4 text-blue-600">
            Education
          </h2>
          <div className="space-y-4">
            {education.map((edu) => (
              <div key={edu.id} className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-gray-900">
                    {edu.degree} in {edu.field}
                  </h3>
                  <p className="text-blue-600">{edu.institution}</p>
                  {edu.honors && (
                    <p className="text-sm text-gray-600">{edu.honors}</p>
                  )}
                </div>
                <div className="text-right text-sm text-gray-600">
                  <p>
                    {edu.startDate} - {edu.endDate}
                  </p>
                  {edu.gpa && <p>GPA: {edu.gpa}</p>}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4 text-blue-600">
            Skills
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {['Technical', 'Soft', 'Language', 'Certification'].map((category) => {
              const categorySkills = skills.filter((skill) => skill.category === category);
              if (categorySkills.length === 0) return null;
              
              return (
                <div key={category}>
                  <h3 className="font-semibold text-gray-900 mb-2">{category}</h3>
                  <div className="space-y-1">
                    {categorySkills.map((skill) => (
                      <div key={skill.id} className="flex justify-between items-center">
                        <span className="text-gray-700">{skill.name}</span>
                        <span className="text-xs text-gray-500">{skill.level}</span>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};

export default ModernTemplate;