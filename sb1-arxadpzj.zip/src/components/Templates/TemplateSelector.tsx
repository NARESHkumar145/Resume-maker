import React from 'react';
import { Check } from 'lucide-react';
import { motion } from 'framer-motion';

interface TemplateOption {
  id: string;
  name: string;
  preview: string;
  description: string;
  category: 'Modern' | 'Classic' | 'Creative' | 'Professional';
}

interface TemplateSelectorProps {
  selectedTemplate: string;
  onTemplateSelect: (templateId: string) => void;
}

const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  selectedTemplate,
  onTemplateSelect,
}) => {
  const templates: TemplateOption[] = [
    {
      id: 'modern',
      name: 'Modern Professional',
      preview: '/templates/modern-preview.jpg',
      description: 'Clean, modern design with subtle colors',
      category: 'Modern',
    },
    {
      id: 'classic',
      name: 'Classic Executive',
      preview: '/templates/classic-preview.jpg',
      description: 'Traditional layout perfect for corporate roles',
      category: 'Classic',
    },
    {
      id: 'creative',
      name: 'Creative Designer',
      preview: '/templates/creative-preview.jpg',
      description: 'Bold design for creative professionals',
      category: 'Creative',
    },
    {
      id: 'minimal',
      name: 'Minimal Clean',
      preview: '/templates/minimal-preview.jpg',
      description: 'Simple, clean layout focusing on content',
      category: 'Professional',
    },
    {
      id: 'tech',
      name: 'Tech Professional',
      preview: '/templates/tech-preview.jpg',
      description: 'Modern layout designed for tech roles',
      category: 'Modern',
    },
    {
      id: 'academic',
      name: 'Academic Scholar',
      preview: '/templates/academic-preview.jpg',
      description: 'Formal design for academic positions',
      category: 'Classic',
    },
  ];

  const categories = ['Modern', 'Classic', 'Creative', 'Professional'];

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-4">Choose Your Template</h2>
        <p className="text-lg text-gray-600">
          Select a professional template that matches your industry and style
        </p>
      </div>

      {categories.map((category) => (
        <div key={category} className="mb-12">
          <h3 className="text-xl font-semibold text-gray-900 mb-6 border-b border-gray-200 pb-2">
            {category}
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates
              .filter((template) => template.category === category)
              .map((template) => (
                <motion.div
                  key={template.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  whileHover={{ scale: 1.02 }}
                  transition={{ duration: 0.2 }}
                  className={`relative cursor-pointer rounded-2xl overflow-hidden border-2 transition-all ${
                    selectedTemplate === template.id
                      ? 'border-blue-500 shadow-lg'
                      : 'border-gray-200 hover:border-gray-300'
                  }`}
                  onClick={() => onTemplateSelect(template.id)}
                >
                  {/* Template Preview */}
                  <div className="aspect-[3/4] bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                    <div className="text-center p-8">
                      <div className="w-full h-32 bg-white rounded-lg shadow-sm mb-4 flex items-center justify-center">
                        <span className="text-gray-400 text-sm">
                          {template.name} Preview
                        </span>
                      </div>
                      <div className="space-y-2">
                        <div className="h-3 bg-gray-300 rounded"></div>
                        <div className="h-2 bg-gray-300 rounded w-3/4"></div>
                        <div className="h-2 bg-gray-300 rounded w-1/2"></div>
                      </div>
                    </div>
                  </div>

                  {/* Template Info */}
                  <div className="p-4 bg-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-gray-900 mb-1">
                          {template.name}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {template.description}
                        </p>
                      </div>
                      
                      {selectedTemplate === template.id && (
                        <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                          <Check size={16} className="text-white" />
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Category Badge */}
                  <div className="absolute top-3 right-3">
                    <span className="bg-white/90 backdrop-blur-sm text-xs font-medium px-2 py-1 rounded-full text-gray-700">
                      {template.category}
                    </span>
                  </div>
                </motion.div>
              ))}
          </div>
        </div>
      ))}
    </div>
  );
};

export default TemplateSelector;