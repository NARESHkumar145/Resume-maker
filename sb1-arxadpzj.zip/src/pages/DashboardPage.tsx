import React from 'react';
import { Plus, FileText, Calendar, TrendingUp } from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const DashboardPage: React.FC = () => {
  const mockResumes = [
    {
      id: '1',
      name: 'Software Engineer Resume',
      template: 'Modern Professional',
      lastModified: '2024-01-15',
      atsScore: 85,
    },
    {
      id: '2',
      name: 'Product Manager Resume',
      template: 'Classic Executive',
      lastModified: '2024-01-10',
      atsScore: 92,
    },
  ];

  const stats = [
    { label: 'Total Resumes', value: '3', icon: FileText, color: 'bg-blue-500' },
    { label: 'This Month', value: '2', icon: Calendar, color: 'bg-green-500' },
    { label: 'Avg ATS Score', value: '88%', icon: TrendingUp, color: 'bg-purple-500' },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
          <p className="text-gray-600">Manage your resumes and track your progress</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {stats.map((stat, index) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="bg-white rounded-2xl p-6 shadow-lg"
            >
              <div className="flex items-center">
                <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center mr-4`}>
                  <stat.icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">{stat.value}</div>
                  <div className="text-sm text-gray-600">{stat.label}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Create New Resume */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="text-center">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">
              Ready to create your next resume?
            </h2>
            <Link
              to="/builder"
              className="inline-flex items-center px-6 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white font-medium rounded-xl hover:from-blue-700 hover:to-purple-700 transition-all"
            >
              <Plus className="w-5 h-5 mr-2" />
              Create New Resume
            </Link>
          </div>
        </div>

        {/* Recent Resumes */}
        <div className="bg-white rounded-2xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-gray-900">Your Resumes</h2>
            <Link to="/templates" className="text-blue-600 hover:text-blue-700 font-medium">
              View All Templates
            </Link>
          </div>

          <div className="space-y-4">
            {mockResumes.map((resume, index) => (
              <motion.div
                key={resume.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="flex items-center justify-between p-4 border border-gray-200 rounded-xl hover:shadow-md transition-shadow"
              >
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
                    <FileText className="w-6 h-6 text-gray-500" />
                  </div>
                  <div>
                    <h3 className="font-medium text-gray-900">{resume.name}</h3>
                    <p className="text-sm text-gray-600">Template: {resume.template}</p>
                    <p className="text-xs text-gray-500">
                      Last modified: {new Date(resume.lastModified).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <div className="text-sm font-medium text-gray-900">
                      ATS Score: {resume.atsScore}%
                    </div>
                    <div className="w-16 h-2 bg-gray-200 rounded-full">
                      <div
                        className="h-2 bg-green-500 rounded-full"
                        style={{ width: `${resume.atsScore}%` }}
                      ></div>
                    </div>
                  </div>
                  
                  <button className="px-4 py-2 text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50 transition-colors">
                    Edit
                  </button>
                </div>
              </motion.div>
            ))}
          </div>

          {mockResumes.length === 0 && (
            <div className="text-center py-12 text-gray-500">
              <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>No resumes yet. Create your first one!</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;